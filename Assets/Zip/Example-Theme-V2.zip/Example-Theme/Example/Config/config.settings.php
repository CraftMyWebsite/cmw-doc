<?php

use CMW\Manager\Theme\Editor\Entities\EditorMenu;
use CMW\Manager\Theme\Editor\Entities\EditorRangeOptions;
use CMW\Manager\Theme\Editor\Entities\EditorSelectOptions;
use CMW\Manager\Theme\Editor\Entities\EditorType;
use CMW\Manager\Theme\Editor\Entities\EditorValue;

return [
    new EditorMenu(
        title: 'Globaux',
        key: 'global',
        scope: null,
        requiredPackage: null,
        values: [
            new EditorValue(
                title: 'Couleur du body',
                themeKey: 'body_color',
                defaultValue: '#d8a629',
                type: EditorType::COLOR
            ),
            new EditorValue(
                title: 'Logo',
                themeKey: 'header_img_logo',
                defaultValue: 'Config/Default/Img/logo_dark.png',
                type: EditorType::IMAGE
            ),
        ]
    ),

    new EditorMenu(
        title: 'Accueil',
        key: 'home',
        scope: null,
        requiredPackage: null,
        values: [
            new EditorValue(
                title: 'Titre',
                themeKey: 'home_title',
                defaultValue: 'Home',
                type: EditorType::TEXT
            ),
            new EditorValue(
                title: 'Formulaire de contact',
                themeKey: 'contact_section_active',
                defaultValue: '1',
                type: EditorType::BOOLEAN
            ),
            new EditorValue(
                title: 'Section Contact',
                themeKey: 'contact_section_title',
                defaultValue: 'Contact Us',
                type: EditorType::TEXT
            ),
            new EditorValue(
                title: 'Section personnalisé',
                themeKey: 'custom_section_active_1',
                defaultValue: '0',
                type: EditorType::BOOLEAN
            ),
            new EditorValue(
                title: 'Titre',
                themeKey: 'custom_section_title_1',
                defaultValue: 'Custom Title 1',
                type: EditorType::TEXT
            ),
            new EditorValue(
                title: 'Titre',
                themeKey: 'custom_section_content_1',
                defaultValue: 'Personnalisez moi',
                type: EditorType::TEXTAREA
            ),
        ]
    ),

    new EditorMenu(
        title: 'Footer',
        key: 'footer',
        scope: null,
        requiredPackage: null,
        values: [
            new EditorValue(
                title: 'Texte',
                themeKey: 'footer_text',
                defaultValue: 'Zomb make greats tuto !',
                type: EditorType::TEXT
            ),
        ]
    ),
];
