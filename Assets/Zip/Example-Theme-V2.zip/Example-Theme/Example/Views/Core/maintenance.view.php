<?php

use CMW\Utils\Website;

/* @var \CMW\Entity\Core\MaintenanceEntity $maintenance */

/* TITRE ET DESCRIPTION */
Website::setTitle('');
Website::setDescription('');
?>


<?php if ($maintenance->isEnable()): ?>
    <h1><?= $maintenance->getTitle() ?></h1>
    <p><?= $maintenance->getDescription() ?></p>
    <hr>
    <h3>End: <?= $maintenance->getTargetDateFormatted() ?></h3>
<?php endif; ?>
