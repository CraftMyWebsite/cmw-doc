<?php

use CMW\Controller\Core\PackageController;
use CMW\Controller\Core\SecurityController;
use CMW\Controller\Users\UsersController;
use CMW\Manager\Security\SecurityManager;
use CMW\Utils\Website;

/* TITRE ET DESCRIPTION */
Website::setTitle('Home');
Website::setDescription(Website::getWebsiteDescription());
?>

    <!-- Contact -->
<?php if (PackageController::isInstalled('Contact')): ?>
<span data-cmw-visible="home:contact_section_active">
    <h3 data-cmw="home:contact_section_title"></h3>
        <form action="contact" method="post">
            <?php (new SecurityManager())->insertHiddenToken() ?>
            <div>
                <label for="email">Mail</label>
                <input name="email" type="email" placeholder="mail@craftmywebsite.fr" required>
            </div>
            <div>
                <label for="name">Name</label>
                <input name="name" type="text" placeholder="Jean" required>
            </div>
            <div>
                <label for="email">Object</label>
                <input name="object" type="text" placeholder="" required>
            </div>
            <div>
                <label for="email">Message</label>
                <textarea name="content" minlength="50"></textarea>
            </div>
            <?php SecurityController::getPublicData(); ?>
            <button type="submit">Send</button>
        </form>
</span>
<?php else: ?>
    <?php if (UsersController::isAdminLogged()): ?>
        Example supports Contact package, currently you don't use it, install it if you want to benefit from it.
        <br>Only admin see this !
    <?php endif; ?>
<?php endif; ?>

    <span data-cmw-visible="home:custom_section_active_1">
    <h3 data-cmw="home:custom_section_title_1"></h3>
    <p data-cmw="home:custom_section_content_1"></p>
    </span>