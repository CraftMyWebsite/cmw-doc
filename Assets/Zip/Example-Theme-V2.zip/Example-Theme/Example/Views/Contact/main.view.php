<?php

use CMW\Controller\Core\SecurityController;
use CMW\Manager\Security\SecurityManager;
use CMW\Utils\Website;

Website::setTitle("Contact");
Website::setDescription("Contact us");
?>

<form method="post">
    <?php (new SecurityManager())->insertHiddenToken() ?>
    <div>
        <label for="email">Mail</label>
        <input name="email" type="email" placeholder="mail@craftmywebsite.fr" required>
    </div>
    <div>
        <label for="name">Name</label>
        <input name="name" type="text" placeholder="Jean" required>
    </div>
    <div>
        <label for="email">Object</label>
        <input name="object" type="text" placeholder="" required>
    </div>
    <div>
        <label for="email">Message</label>
        <textarea name="content" minlength="50"></textarea>
    </div>
    <?php SecurityController::getPublicData(); ?>
    <button type="submit">Send</button>
</form>
