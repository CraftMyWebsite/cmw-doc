<?php

use CMW\Model\Core\ThemeModel;

?>
<hr>
<p data-cmw="footer:footer_text"></p>
