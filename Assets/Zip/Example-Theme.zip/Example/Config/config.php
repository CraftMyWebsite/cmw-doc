<?php use CMW\Controller\Core\PackageController;
use CMW\Model\Core\ThemeModel;

?>
<!-------------->
<!--Navigation-->
<!-------------->
<div class="tab-menu">
    <ul class="tab-horizontal" data-tabs-toggle="#tab-content-config">
        <li>
            <button type="button" data-tabs-target="#tab1" role="tab">Global</button>
        </li>
        <li>
            <button type="button" data-tabs-target="#tab2" role="tab">Accueil</button>
        </li>
        <?php if (PackageController::isInstalled('Contact')): ?>
            <li>
                <button type="button" data-tabs-target="#tab3" role="tab">Contact</button>
            </li>
        <?php endif; ?>
        <li>
            <button type="button" data-tabs-target="#tab4" role="tab">Footer</button>
        </li>
    </ul>
</div>

<div id="tab-content-config">
    <!--
    Global
    -->
    <div class="tab-content" id="tab1">
        <h6>Image :</h6>
        <div class="grid-2">
            <div class="flex justify-center">
                <img class="w-25" src="<?= ThemeModel::getInstance()->fetchImageLink('header_img_logo') ?>"
                     alt="Image introuvable !">
            </div>
            <div class="drop-img-area mt-4" data-input-name="header_img_logo"></div>
        </div>
        <label for="bg">Background color :</label>
        <input id="bg" type="color" name="body_color"
               value="<?= ThemeModel::getInstance()->fetchConfigValue('body_color') ?>">
    </div>
    <!--
   ACCUEIL
   -->
    <div class="tab-content" id="tab2">
        <h6>Page indexing (meta):</h6>
        <div class="alert-warning">
            <h6 class="alert-heading">Understanding indexing</h6>
            <p>These options change the title and description of your page in the tab, but also when displayed on
                Discord, Twitter...<br>
                This is not related to the title of the page being edited. This option is located a little
                lower (If your page is eligible for this setting).<br>
                If you need further assistance you can contact CraftMyWebsite support.</p>
        </div>
        <label for="home_title">Page Title:</label>
        <input type="text" id="home_title" name="home_title"
               value="<?= ThemeModel::getInstance()->fetchConfigValue('home_title') ?>" required class="input">
        <hr>
        <?php if (PackageController::isInstalled('Contact')): ?>
            <div>
                <label class="toggle">
                    <h5 class="toggle-label">Contact :</h5>
                    <input type="checkbox" class="toggle-input" id="contact_section_active"
                           name="contact_section_active" <?= ThemeModel::getInstance()->fetchConfigValue('contact_section_active') ? 'checked' : '' ?>>
                    <div class="toggle-slider"></div>
                </label>
            </div>
            <label for="contact_section_title">Section title :</label>
            <input type="text" class="input" id="contact_section_title" name="contact_section_title"
                   value="<?= ThemeModel::getInstance()->fetchConfigValue('contact_section_title') ?>" required>
        <?php endif; ?>
        <hr>
        <div>
            <label class="toggle">
                <h5 class="toggle-label">Customisable 1 :</h5>
                <input type="checkbox" class="toggle-input" id="custom_section_active_1"
                       name="custom_section_active_1" <?= ThemeModel::getInstance()->fetchConfigValue('custom_section_active_1') ? 'checked' : '' ?>>
                <div class="toggle-slider"></div>
            </label>
        </div>
        <label for="custom_section_title_1">Section title :</label>
        <input type="text" class="input" id="custom_section_title_1" name="custom_section_title_1"
               value="<?= ThemeModel::getInstance()->fetchConfigValue('custom_section_title_1') ?>" required>
        <label for="custom_section_content_1">Content :</label>
        <textarea id="custom_section_content_1" name="custom_section_content_1"
                  class="tinymce"><?= ThemeModel::getInstance()->fetchConfigValue('custom_section_content_1') ?></textarea>
    </div>
    <!--
    Contact
    -->
    <?php if (PackageController::isInstalled('Contact')): ?>
        <div class="tab-content" id="tab3">
            <h6>Page indexing (meta):</h6>
            <div class="alert-warning">
                <h6 class="alert-heading">Understanding indexing</h6>
                <p>These options change the title and description of your page in the tab, but also when displayed on
                    Discord, Twitter...<br>
                    This is not related to the title of the page being edited. This option is located a little
                    lower (If your page is eligible for this setting).<br>
                    If you need further assistance you can contact CraftMyWebsite support.</p>
            </div>
            <div class="grid-2">
                <div>
                    <label for="contact_title">Page Title:</label>
                    <input type="text" class="input" id="contact_title" name="contact_title"
                           value="<?= ThemeModel::getInstance()->fetchConfigValue('contact_title') ?>" required>
                </div>
                <div>
                    <label for="contact_description">Page Description:</label>
                    <input type="text" class="input" id="contact_description" name="contact_description"
                           value="<?= ThemeModel::getInstance()->fetchConfigValue('contact_description') ?>" required>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <!--
    Footer
    -->
    <div class="tab-content" id="tab4">
        <div>
            <label for="footer_text">Footer text:</label>
            <input type="text" class="input" id="footer_text" name="footer_text"
                   value="<?= ThemeModel::getInstance()->fetchConfigValue('footer_text') ?>" required>
        </div>
    </div>
</div>