<?php

return [
    /* - - - - - - - -
        - - HEADER & GLOBAL - -
     - - - - - - - - - */
    "body_color" => "#d8a629",
    "header_img_logo" => "Config/Default/Img/logo_dark.png",

    /* - - - - - - - -
       - - HOME - -
    - - - - - - - - - */
    /* TITLE DESC */
    'home_title' => 'Home',
    /* CONTACT SECTION */
    'contact_section_active' => '1',
    'contact_section_title' => 'Contact Us',
    /* CUSTOM SECTION #1 */
    'custom_section_active_1' => '0',
    'custom_section_title_1' => 'Custom Title 1',
    'custom_section_content_1' => '<h1>Custom me</h1> <br> <p>Like HTML !</p>',


    /* - - - - - - - -
       - - CONTACT PAGE - -
    - - - - - - - - - */
    'contact_title' => 'Contact',
    'contact_description' => 'Contact description',

    /* - - - - - - - -
       - - FOOTER - -
    - - - - - - - - - */
    'footer_text' => 'Zomb make greats tuto !',
];
