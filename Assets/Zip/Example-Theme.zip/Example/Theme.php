<?php

/*---------------------------------------------------------------------
 * N'oubliez pas de changer le NAMESPACE par le nom du dossier du thème
 * Si le dossier de votre thème s'appel Test votre NAMESPACE sera :
 * namespace CMW\Theme\Test;
---------------------------------------------------------------------*/
namespace CMW\Theme\Example;

use CMW\Manager\Theme\IThemeConfig;

class Theme implements IThemeConfig
{
    public function name(): string
    {
        return 'Example';
    }

    public function version(): string
    {
        return '0.0.1';
    }

    public function cmwVersion(): string
    {
        return '2.0';
    }

    public function author(): ?string
    {
        return 'YourName';
    }

    public function authors(): array
    {
        return [];
    }

    public function compatiblesPackages(): array
    {
        return [
            'Core',
            'Pages',
            'Users',
            'Contact',
        ];
    }

    public function requiredPackages(): array
    {
        return ['Core', 'Users', 'Pages'];
    }
}
