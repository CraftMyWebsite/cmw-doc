<?php

use CMW\Utils\Website;

Website::setTitle('');
Website::setDescription('');

?>
Error