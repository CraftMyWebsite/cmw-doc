<?php

use CMW\Utils\Website;

Website::setTitle('');
Website::setDescription('');

?>
404 error