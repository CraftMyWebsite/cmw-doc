<?php

use CMW\Model\Core\ThemeModel;

?>
<hr>
<?= ThemeModel::getInstance()->fetchConfigValue('footer_text') ?>
