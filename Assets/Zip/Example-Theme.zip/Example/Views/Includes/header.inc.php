<?php

use CMW\Controller\Users\UsersController;
use CMW\Manager\Env\EnvManager;
use CMW\Model\Core\MenusModel;
use CMW\Model\Core\ThemeModel;
use CMW\Model\Users\UsersModel;
use CMW\Utils\Website;

$menus = MenusModel::getInstance();
?>
<h1><?= Website::getWebsiteName() ?></h1>

<img src="<?= ThemeModel::getInstance()->fetchImageLink("header_img_logo") ?>" alt="logo" width="100px">

<?php if (UsersController::isUserLogged()): ?>
<p><?= UsersModel::getCurrentUser()->getPseudo() ?> :</p>
    <ul>
        <?php if (UsersController::isAdminLogged()): ?>
            <li>
                <a href="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>cmw-admin" target="_blank">Administration</a>
            </li>
        <?php endif; ?>
        <li>
            <a href="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>profile">Profil</a>
        </li>
        <li>
            <a href="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>logout">Logout</a>
        </li>
    </ul>
<?php else: ?>
    <a href="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>login" class="">Login</a>
    <a href="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>register">Register</a>
<?php endif; ?>
<ul>
    <?php foreach ($menus->getMenus() as $menu): ?>
        <?php if ($menu->isUserAllowed()): ?>
            <li <?php if ($menu->urlIsActive()) { echo 'style="color : blue;"'; } ?>>
                <a href="<?= $menu->getUrl() ?>" <?= !$menu->isTargetBlank() ?: "target='_blank'" ?>><?= $menu->getName() ?></a>
            </li>
            <div>
                <?php foreach ($menus->getSubMenusByMenu($menu->getId()) as $subMenu): ?>
                    <?php if ($subMenu->isUserAllowed()): ?>
                        <ul>
                            <li>
                                <a href="<?= $subMenu->getUrl() ?>" type="button" <?= !$subMenu->isTargetBlank() ?: "target='_blank'" ?>><?= $subMenu->getName() ?></a>
                                <?php foreach ($menus->getSubMenusByMenu($subMenu->getId()) as $subSubMenu): ?>
                                    <?php if ($subSubMenu->isUserAllowed()): ?>
                                        <ul class="py-1 text-sm text-gray-700" aria-labelledby="doubleDropdownButton">
                                            <li>
                                                <a href="<?= $subSubMenu->getUrl() ?>" class="block py-2 px-4 hover:bg-gray-100" <?= !$subSubMenu->isTargetBlank() ?: "target='_blank'" ?>><?= $subSubMenu->getName() ?></a>
                                            </li>
                                        </ul>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </li>
                        </ul>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</ul>
<hr>







