<?php

/* @var \CMW\Entity\Users\UserEntity $user */

use CMW\Manager\Env\EnvManager;
use CMW\Manager\Security\SecurityManager;
use CMW\Utils\Website;

Website::setTitle('');
Website::setDescription("");
?>


<form action="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>profile/2fa/toggle" method="post">
    <?php (new SecurityManager())->insertHiddenToken() ?>
    <input type="text" hidden="" name="enforce_mail" value="<?= $user->getMail() ?>">
    <label for="secret">Code</label>
    <input type="text" name="secret" id="secret" required>
    <button type="submit">Enable</button>
</form>