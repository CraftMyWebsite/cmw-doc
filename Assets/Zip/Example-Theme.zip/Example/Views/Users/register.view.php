<?php

use CMW\Controller\Core\SecurityController;
use CMW\Manager\Security\SecurityManager;
use CMW\Utils\Website;

Website::setTitle('');
Website::setDescription('');
?>


<form action="" method="post">
    <?php (new SecurityManager())->insertHiddenToken() ?>
    <label for="email" class="block mb-2 text-sm font-medium text-gray-900">Mail</label>
    <input name="register_email" type="email" placeholder="Mail" required>
    <label for="email" class="block mb-2 text-sm font-medium text-gray-900">Name</label>
    <input name="register_pseudo" type="text" placeholder="Name"
           required>
    <label for="password" class="block mb-2 text-sm font-medium text-gray-900">Password</label>
    <input id="passwordInput" type="password" name="register_password"
           placeholder="..." required>
    <div onclick="showPassword()"><i class="fa fa-eye-slash"></i></div>
    <label for="password">Repeat password</label>
    <input id="passwordInputV" type="password" name="register_password_verify"
           placeholder="..." required>
    <div onclick="showPasswordV()"><i class="fa fa-eye-slash"></i></div>
    <?php SecurityController::getPublicData(); ?>
    <button type="submit">Register</button>
</form>


<script>
    function showPassword() {
        var x = document.getElementById("passwordInput");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
    function showPasswordV() {
        var x = document.getElementById("passwordInputV");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>