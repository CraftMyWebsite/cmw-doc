<?php

/* @var \CMW\Entity\Users\UserEntity $user */

use CMW\Manager\Env\EnvManager;
use CMW\Manager\Security\SecurityManager;
use CMW\Utils\Website;

Website::setTitle('');
Website::setDescription('');
?>

<h2><?= $user->getPseudo() ?></h2>


<p>Personal informations</p>
<form action="profile/update" method="post">
    <?php (new SecurityManager())->insertHiddenToken() ?>
    <label for="email" class="block mb-2 text-sm font-medium text-gray-900">Votre mail</label>
    <input type="email" name="email" id="email" value="<?= $user->getMail() ?>" required>

    <label for="email" class="block mb-2 text-sm font-medium text-gray-900">Pseudo / Nom d'affichage</label>
    <input type="text" name="pseudo" id="pseudo" value="<?= $user->getPseudo() ?>" required>

    <label for="password" class="block mb-2 text-sm font-medium text-gray-900">Mot de passe</label>
    <input type="password" name="password" id="password" placeholder="********" required>

    <label for="password" class="block mb-2 text-sm font-medium text-gray-900">Confirmation</label>
    <input type="password" name="passwordVerif" id="passwordVerif" placeholder="********" required>

    <button type="submit">Appliquer les modifications</button>
</form>

<p>
    <?php if ($user->get2Fa()->isEnabled()): ?>
        <span style="color: #188c1a;">Security (ON) <i class="fa-solid fa-check"></i></span>
    <?php else: ?>
        <span style="color: #bc2015;">Security (OFF) <i class="fa-solid fa-triangle-exclamation"></i></span>
    <?php endif; ?>
</p>
<img class="mx-auto" height="50%" width="50%" src='<?= $user->get2Fa()->getQrCode(250) ?>' alt="QR Code">
<span><?= $user->get2Fa()->get2FaSecretDecoded() ?></span>

<form action="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>profile/2fa/toggle" method="post">
    <?php (new SecurityManager())->insertHiddenToken() ?>
    <label for="secret">Code d'authentification</label>
    <input type="text" name="secret" id="secret" required>
    <button type="submit"><?= $user->get2Fa()->isEnabled() ? 'Disable' : 'Enable' ?></button>
</form>


<p class="text-center uppercase font-bold mb-2">Visual identity</p>
<?php if (!is_null($user->getUserPicture()?->getImage())): ?>
    <label>Image :</label>
    <img src="<?= $user->getUserPicture()->getImage() ?>" height="50%" width="50%" alt="<?= $user->getPseudo() ?>">
<?php endif; ?>


<form action="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>profile" method="post"
      enctype="multipart/form-data">
    <?php (new SecurityManager())->insertHiddenToken() ?>
    <label for="password">Change image :</label>

    <input type="file" id="pictureProfile" name="pictureProfile" accept=".png, .jpg, .jpeg, .webp, .gif" required>
    <button type="submit">Sauvegarder</button>
</form>


<a href="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>profile/delete/<?= $user->getId() ?>">Delete my
    account</a>

