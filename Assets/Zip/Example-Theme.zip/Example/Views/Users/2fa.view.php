<?php

use CMW\Manager\Security\SecurityManager;
use CMW\Manager\Env\EnvManager;
use CMW\Utils\Website;

Website::setTitle('');
Website::setDescription('');

?>

<form action="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') . 'login/validate/tfa' ?>" method="post">
    <?php (new SecurityManager())->insertHiddenToken() ?>
    <label for="code">Code</label>
    <input type="text" name="code" id="code" required>
    <button type="submit">Connect</button>
</form>
