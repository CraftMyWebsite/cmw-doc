<?php

use CMW\Controller\Core\SecurityController;
use CMW\Manager\Env\EnvManager;
use CMW\Manager\Security\SecurityManager;
use CMW\Utils\Website;

Website::setTitle('');
Website::setDescription('' . Website::getWebsiteName());
?>

<form action="" method="post">
    <?php (new SecurityManager())->insertHiddenToken() ?>
    <input hidden name="previousRoute" type="text" value="<?= $_SERVER['HTTP_REFERER'] ?>">

    <label for="email">Mail</label>
    <input name="login_email" type="email" placeholder="mail@craftmywebsite.fr" required>

    <label for="passwordInput">Mot de passe</label>
    <input type="password" name="login_password" id="passwordInput" placeholder="••••••••" required>
    <div onclick="showPassword()"><i class="fa fa-eye-slash" aria-hidden="true"></i></div>

    <input id="login_keep_connect" name="login_keep_connect" type="checkbox" value="">
    <label for="login_keep_connect">Remember me</label>
    <a href="<?= EnvManager::getInstance()->getValue('PATH_SUBFOLDER') ?>login/forgot">Forgot password</a>
    <?php SecurityController::getPublicData(); ?>
    <button type="submit">Connect</button>
</form>


<script>
    function showPassword() {
        var x = document.getElementById("passwordInput");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
</script>