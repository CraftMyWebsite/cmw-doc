<?php

use CMW\Controller\Core\SecurityController;
use CMW\Manager\Security\SecurityManager;
use CMW\Utils\Website;

/* TITRE ET DESCRIPTION */
Website::setTitle('');
Website::setDescription("");
?>

<form action="" method="post">
    <?php (new SecurityManager())->insertHiddenToken() ?>
    <label for="email">Mail</label>
    <input name="mail" id="email" type="email" required>
    <?php SecurityController::getPublicData(); ?>
    <button type="submit">Send</button>
</form>