<?php

use CMW\Utils\Website;

/* @var \CMW\Entity\Core\ConditionEntity $cgv */

/* TITRE ET DESCRIPTION */
Website::setTitle('');
Website::setDescription('');
?>

<?= $cgv->getContent() ?>

<p>By <b><?= $cgv->getLastEditor()->getPseudo() ?></b>, updated <?= $cgv->getUpdate() ?></p>

