<?php

use CMW\Utils\Website;

/* @var \CMW\Entity\Core\ConditionEntity $cgu */

/* TITRE ET DESCRIPTION */
Website::setTitle('');
Website::setDescription("");
?>

<?= $cgu->getContent() ?>

<p>By <b><?= $cgu->getLastEditor()->getPseudo() ?></b>, updated <?= $cgu->getUpdate() ?></p>
