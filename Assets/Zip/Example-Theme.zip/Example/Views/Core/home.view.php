<?php

use CMW\Controller\Core\PackageController;
use CMW\Controller\Core\SecurityController;
use CMW\Controller\Users\UsersController;
use CMW\Manager\Security\SecurityManager;
use CMW\Model\Core\ThemeModel;
use CMW\Utils\Website;

/* TITRE ET DESCRIPTION */
Website::setTitle(ThemeModel::getInstance()->fetchConfigValue('home_title'));
Website::setDescription(Website::getWebsiteDescription());
?>

    <!-- Contact -->
<?php if (PackageController::isInstalled('Contact')): ?>
    <?php if (ThemeModel::getInstance()->fetchConfigValue('contact_section_active')): ?>
    <h3><?= ThemeModel::getInstance()->fetchConfigValue('contact_section_title') ?></h3>
        <form action="contact" method="post">
            <?php (new SecurityManager())->insertHiddenToken() ?>
            <div>
                <label for="email">Mail</label>
                <input name="email" type="email" placeholder="mail@craftmywebsite.fr" required>
            </div>
            <div>
                <label for="name">Name</label>
                <input name="name" type="text" placeholder="Jean" required>
            </div>
            <div>
                <label for="email">Object</label>
                <input name="object" type="text" placeholder="" required>
            </div>
            <div>
                <label for="email">Message</label>
                <textarea name="content" minlength="50"></textarea>
            </div>
            <?php SecurityController::getPublicData(); ?>
            <button type="submit">Send</button>
        </form>
    <?php endif; ?>
<?php else: ?>
    <?php if (UsersController::isAdminLogged()): ?>
        Example supports Contact package, currently you don't use it, install it if you want to benefit from it.
        <br>Only admin see this !
    <?php endif; ?>
<?php endif; ?>

<?php if (ThemeModel::getInstance()->fetchConfigValue('custom_section_active_1')): ?>
    <h3><?= ThemeModel::getInstance()->fetchConfigValue('custom_section_title_1') ?></h3>
    <?= ThemeModel::getInstance()->fetchConfigValue('custom_section_content_1') ?>
<?php endif; ?>